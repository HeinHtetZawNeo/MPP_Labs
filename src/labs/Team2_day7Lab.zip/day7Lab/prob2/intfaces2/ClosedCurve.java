package labs.day7Lab.prob2.intfaces2;

public interface ClosedCurve {
	public double computePerimeter();
}
